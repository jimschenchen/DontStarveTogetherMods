local strings = {}
strings.WORLD = "World: "
strings.WHERE_TO_GO = "Where to go?"
strings.HERE_IS = "Here is "
strings.WORLD_FULL = "That world is FULL"
strings.WORLD_INVALID = "That world is invalid"
strings.SELECT_WORLD = "Select World"
strings.PLAYER_COUNT = "Count: "
strings.LEAVE_FOR = "GO"
strings.GOING_TO = "I`m going to "

GLOBAL.STRINGS.MWP = strings
