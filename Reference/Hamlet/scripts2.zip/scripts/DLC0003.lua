local function Setup()
	TheSim:LoadPrefabs({"DLC0003"})
end

return {Setup = Setup}
