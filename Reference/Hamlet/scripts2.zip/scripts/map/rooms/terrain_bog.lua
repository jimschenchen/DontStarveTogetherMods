
AddRoom("BG_painted_base", {
					colour={r=1.0,g=1.0,b=1.0,a=0.3},
					value = GROUND.PAINTED,
					tags = {"ExitPiece","Bramble"},
					contents =  {
					                distributepercent = .15, --.26
					                distributeprefabs=
					                {
										tubertree = 1,
										rock1 = 0.1,
										rocks = 0.1,
										nitre = 0.1,
										flint = 0.05,										
					                },
					                countprefabs = 
					                {
					                	vampirebatcave_potential = 1,
					            	},
					            }
					})