
AddRoom("BG_interior_base", {
					colour={r=.01,g=0.01,b=0.01,a=0.3},
					value = GROUND.INTERIOR,
					tags = {"interior_potential"},
					contents =  {
					                distributepercent = 0.0,
					                distributeprefabs=
					                {										

					                },			                
					            }
					})