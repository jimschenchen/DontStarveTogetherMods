local function Setup()
	TheSim:LoadPrefabs({"DLC0002"})
end

return {Setup = Setup}
