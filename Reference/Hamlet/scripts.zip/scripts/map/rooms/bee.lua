
AddRoom("BeeClearing", {
					colour={r=.8,g=1,b=.8,a=.50},
					value = GROUND.GRASS,
					contents =  {
					                countprefabs= {
                                        fireflies= 1,
					                    flower=6,
					                    beehive=1,
					                }
					            }
					})
