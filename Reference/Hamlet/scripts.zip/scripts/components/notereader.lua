local NoteReader = Class(function(self,inst)

end)

return NoteReader