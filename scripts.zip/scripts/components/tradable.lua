local Tradable = Class(function(self, inst)
    self.inst = inst
    self.goldvalue = 0
    
    --self.tradefor = nil -- this is an array
    --self.rocktribute = nil
end)

return Tradable